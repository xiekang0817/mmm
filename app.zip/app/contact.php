<!DOCTYPE html>
<html lang="en-US" xmlns:fb="http://ogp.me/ns/fb#" xmlns:addthis="http://www.addthis.com/help/api-spec" >
<head>
	<meta name="google-site-verification" content="n3c8shveUUwqqulGbcCztIsTsGzV9fTBSKSF1qFRGag" />
	<meta charset="UTF-8">
	<meta name="viewport" content="initial-scale=1,maximum-scale=1,user-scalable=no">
	<meta name="p:domain_verify" content="a2cc460fc845559e6f7640d9176ecbe8"/>
	<meta name="msvalidate.01" content="1C005310753D33A52D8E3AB189963AB0" />
	

	<title>Nothing found for  Website Mobilizer Maxgymnasia Contact Php</title>

<!-- All in One SEO Pack 2.3.9.2 by Michael Torbert of Semper Fi Web Design[495,537] -->
<link rel="author" href="../../../../https@plus.google.com/+MaxartkillerIn" />

			<!--ipt>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

			ga('create', 'UA-58049153-1', 'auto');
			
			ga('send', 'pageview');
			</scri-->
					<script type="text/javascript">
						function recordOutboundLink(link, category, action) {
														ga('send', 'event', category, action);
														if (link.target == '_blank') return true;
							setTimeout('document.location = "' + link.href + '"', 100);
							return false;
						}
						/* use regular Javascript for this */
						function getAttr(ele, attr) {
							var result = (ele.getAttribute && ele.getAttribute(attr)) || null;
							if (!result) {
								var attrs = ele.attributes;
								var length = attrs.length;
								for (var i = 0; i < length; i++)
									if (attr[i].nodeName === attr) result = attr[i].nodeValue;
							}
							return result;
						}

						function aiosp_addLoadEvent(func) {
							var oldonload = window.onload;
							if (typeof window.onload != 'function') {
								window.onload = func;
							} else {
								window.onload = function () {
									if (oldonload) {
										oldonload();
									}
									func();
								}
							}
						}

						function aiosp_addEvent(element, evnt, funct) {
							if (element.attachEvent)
								return element.attachEvent('on' + evnt, funct);
							else
								return element.addEventListener(evnt, funct, false);
						}

						aiosp_addLoadEvent(function () {
							var links = document.getElementsByTagName('a');
							for (var x = 0; x < links.length; x++) {
								if (typeof links[x] == 'undefined') continue;
								aiosp_addEvent(links[x], 'onclick', function () {
									var mydomain = new RegExp(document.domain, '127.0.0.1');
									href = getAttr(this, 'href');
									if (href && href.toLowerCase().indexOf('http') === 0 && !mydomain.test(href)) {
										recordOutboundLink(this, 'Outbound Links', href);
									}
								});
							}
						});
					</script>
					<!-- /all in one seo pack -->
<link rel='dns-prefetch' href='../../../../fonts.googleapis.com/default.htm' />
<link rel='dns-prefetch' href='../../../../s.w.org/default.htm' />
<link rel="alternate" type="application/rss+xml" title="Maxartkiller &raquo; Feed" href="../../../feed/default.htm" />
<link rel="alternate" type="application/rss+xml" title="Maxartkiller &raquo; Comments Feed" href="../../../comments/feed/default.htm" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"../../../../https@s.w.org/images/core/emoji/2/72x72/","ext":".png","svgUrl":"../../../../https@s.w.org/images/core/emoji/2/svg/default.htm","svgExt":".svg","source":{"concatemoji":"../../../wp-includes/js/wp-emoji-release.min.js@ver=d31f437c8b539577ec2875cbda671ec0"}};
			!function(a,b,c){function d(a){var c,d,e,f,g,h=b.createElement("canvas"),i=h.getContext&&h.getContext("2d"),j=String.fromCharCode;if(!i||!i.fillText)return!1;switch(i.textBaseline="top",i.font="600 32px Arial",a){case"flag":return i.fillText(j(55356,56806,55356,56826),0,0),!(h.toDataURL().length<3e3)&&(i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,65039,8205,55356,57096),0,0),c=h.toDataURL(),i.clearRect(0,0,h.width,h.height),i.fillText(j(55356,57331,55356,57096),0,0),d=h.toDataURL(),c!==d);case"diversity":return i.fillText(j(55356,57221),0,0),e=i.getImageData(16,16,1,1).data,f=e[0]+","+e[1]+","+e[2]+","+e[3],i.fillText(j(55356,57221,55356,57343),0,0),e=i.getImageData(16,16,1,1).data,g=e[0]+","+e[1]+","+e[2]+","+e[3],f!==g;case"simple":return i.fillText(j(55357,56835),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode8":return i.fillText(j(55356,57135),0,0),0!==i.getImageData(16,16,1,1).data[0];case"unicode9":return i.fillText(j(55358,56631),0,0),0!==i.getImageData(16,16,1,1).data[0]}return!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i;for(i=Array("simple","flag","unicode8","diversity","unicode9"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
			<style>
			#wp-admin-bar-layers-edit-layout .ab-icon:before{
				font-family: "layers-interface" !important;
				content: "\e62f" !important;
				font-size: 16px !important;
			}
			</style>
		<link rel='stylesheet' id='cd-portfolio-css-group-css' href='../../../wp-content/plugins/bwp-minify/min/@f=wp-content_2Fplugins_2Fcodenovo-portfolio_2Fcss_2Fcodenovo-portfolio-frontend-css.css,wp-content_2Fplug0DBF3CD327' type='text/css' media='all' />
<link rel='stylesheet' id='layers-google-fonts-css'  href='../../../../fonts.googleapis.com/css@family=Open+Sans_253Aregular,italic,700,300,300italic,600,600italic,700italic,800,800italic_257CPlayfair+0EB0E9C29C' type='text/css' media='all' />
<script type='text/javascript' src='../../../wp-includes/js/jquery/jquery.js@ver=1.12.4'></script>
<script type='text/javascript' src='../../../wp-includes/js/jquery/jquery-migrate.min.js@ver=1.4.1'></script>
<script type='text/javascript' src='../../../wp-content/plugins/bwp-minify/min/@f=wp-content_2Fplugins_2Fcodenovo-portfolio_2Fjs_2Fjquery-easing.js,wp-content_2Fplugins_2Fcodenovo-portf0A2E23E3C7'></script>
<link rel='https://api.w.org/' href='../../../wp-json/default.htm' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://maxartkiller.in/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="../../../wp-includes/wlwmanifest.xml" /> 

<script type='text/javascript' data-cfasync='false'>var _mmunch = {'front': false, 'page': false, 'post': false, 'category': false, 'author': false, 'search': false, 'attachment': false, 'tag': false};</script><script data-cfasync="false" src="../../../../a.mailmunch.co/app/v1/site.js" id="mailmunch-script" data-plugin="mailmunch" data-mailmunch-site-id="120055" async></script><script type="text/javascript">
(function(url){
	if(/(?:Chrome\/26\.0\.1410\.63 Safari\/537\.31|WordfenceTestMonBot)/.test(navigator.userAgent)){ return; }
	var addEvent = function(evt, handler) {
		if (window.addEventListener) {
			document.addEventListener(evt, handler, false);
		} else if (window.attachEvent) {
			document.attachEvent('on' + evt, handler);
		}
	};
	var removeEvent = function(evt, handler) {
		if (window.removeEventListener) {
			document.removeEventListener(evt, handler, false);
		} else if (window.detachEvent) {
			document.detachEvent('on' + evt, handler);
		}
	};
	var evts = 'contextmenu dblclick drag dragend dragenter dragleave dragover dragstart drop keydown keypress keyup mousedown mousemove mouseout mouseover mouseup mousewheel scroll'.split(' ');
	var logHuman = function() {
		var wfscr = document.createElement('script');
		wfscr.type = 'text/javascript';
		wfscr.async = true;
		wfscr.src = url + '&r=' + Math.random();
		(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(wfscr);
		for (var i = 0; i < evts.length; i++) {
			removeEvent(evts[i], logHuman);
		}
	};
	for (var i = 0; i < evts.length; i++) {
		addEvent(evts[i], logHuman);
	}
})('../../../@wordfence_logHuman=1&hid=0BDADC858DD1C05441B4076AA892E6D3');
</script>		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<link rel="icon" href="../../../wp-content/uploads/2016/07/cropped-pictweet-32x32.png" sizes="32x32" />
<link rel="icon" href="../../../wp-content/uploads/2016/07/cropped-pictweet-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="../../../wp-content/uploads/2016/07/cropped-pictweet-180x180.png" />
<meta name="msapplication-TileImage" content="http://maxartkiller.in/wp-content/uploads/2016/07/cropped-pictweet-270x270.png" />
	


</head>
<body class="error404 layers-header-sticky has-site-logo">
	<section class="wrapper invert off-canvas-right" id="off-canvas-right">
    <a class="close-canvas l-close" data-toggle="#off-canvas-right" data-toggle-class="open"></a>
    <div class="row content nav-mobile">
        <nav class="nav nav-vertical"><ul id="menu-main-menu" class="menu"><li id="menu-item-149" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-149"><a href="../../../default.htm">Home</a></li>
<li id="menu-item-544" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-544"><a href="#">Templates</a>
<ul class="sub-menu">
	<li id="menu-item-608" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-608"><a href="../../../freebiees/default.htm">Freebiees</a></li>
	<li id="menu-item-641" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-641"><a href="#">Mobile Template</a>
	<ul class="sub-menu">
		<li id="menu-item-592" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-592"><a href="../../../max-solaris-touch-optimized-responsive-tablet-and-mobile-html-template/default.htm">Solaris | Mobile</a></li>
		<li id="menu-item-593" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-593"><a href="../../../maxsmart-html-touch-optimized-responsive-tablet-and-mobile-template/default.htm">MaxSmart | Mobile</a></li>
		<li id="menu-item-594" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-594"><a href="../../../mobilizer-html-touch-optimized-responsive-tablet-and-mobile-template/default.htm">Mobilizer | Mobile</a></li>
	</ul>
</li>
	<li id="menu-item-642" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-642"><a href="#">Website</a>
	<ul class="sub-menu">
		<li id="menu-item-643" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-643"><a href="../../../admin-9-bootstrap-html-template-responsive-dashboard/default.htm">Admin9 Bootstrap</a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-155" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-155"><a href="../../../blog/default.htm">Blog</a></li>
</ul></nav>    </div>
    <aside id="search-2" class="content widget widget_search"><form role="search" method="get" class="search-form" action="http://maxartkiller.in/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form></aside><aside id="categories-2" class="content widget widget_categories"><h5 class="section-nav-title">Categories</h5>		<ul>
	<li class="cat-item cat-item-16"><a href="../../../category/creativity/default.htm" >Creativity</a>
</li>
	<li class="cat-item cat-item-20"><a href="../../../category/devlopment-process/default.htm" >Devlopment Process</a>
</li>
	<li class="cat-item cat-item-68"><a href="../../../category/technology/default.htm" >Technology</a>
</li>
	<li class="cat-item cat-item-100"><a href="../../../category/templates/default.htm" >Templates</a>
</li>
	<li class="cat-item cat-item-76"><a href="../../../category/user-experience/default.htm" >User Experience</a>
</li>
		</ul>
</aside><aside id="archives-2" class="content widget widget_archive"><h5 class="section-nav-title">Archives</h5>		<ul>
			<li><a href='../../../2016/09/default.htm'>September 2016</a></li>
	<li><a href='../../../2016/07/default.htm'>July 2016</a></li>
	<li><a href='../../../2016/05/default.htm'>May 2016</a></li>
	<li><a href='../../../2016/03/default.htm'>March 2016</a></li>
	<li><a href='../../../2016/01/default.htm'>January 2016</a></li>
	<li><a href='../../../2015/12/default.htm'>December 2015</a></li>
	<li><a href='../../../2015/11/default.htm'>November 2015</a></li>
	<li><a href='../../../2015/09/default.htm'>September 2015</a></li>
	<li><a href='../../../2015/08/default.htm'>August 2015</a></li>
		</ul>
		</aside>		<aside id="recent-posts-2" class="content widget widget_recent_entries">		<h5 class="section-nav-title">Recent Posts</h5>		<ul>
					<li>
				<a href="../../../admin9-bootstrap-admin-template-html-responsive-template/default.htm">Admin9 | bootstrap admin template | HTML responsive template</a>
						</li>
					<li>
				<a href="../../../what-are-importance-of-ux-designer-in-development-lifecycle/default.htm">What are importance of UX designer in development lifecycle?</a>
						</li>
					<li>
				<a href="../../../meet-new-new-max-smart-tablet-mobile-responsive-html-template/default.htm">Meet new new: Max Smart | Tablet &#038; Mobile Responsive HTML Template</a>
						</li>
					<li>
				<a href="../../../meet-the-new-mobilizer-multi-purpose-responsive-for-mobile-tablet/default.htm">Meet the new : Mobilizer | Multi Purpose Responsive for Mobile &#038; Tablet</a>
						</li>
					<li>
				<a href="../../../what-is-imagination-and-the-power-of-imagination/default.htm">Imagination and the Power of Imagination?</a>
						</li>
				</ul>
		</aside>		<aside id="recent-comments-2" class="content widget widget_recent_comments"><h5 class="section-nav-title">Recent Comments</h5><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link">jual sepatu safety di jakarta selatan</span> on <a href="../../../agile-and-agile-manifesto/comment-page-1/#comment-1123">Agile Manifesto: What it’s about?</a></li><li class="recentcomments"><span class="comment-author-link">Maxartkiller</span> on <a href="../../../meet-the-new-mobilizer-multi-purpose-responsive-for-mobile-tablet/comment-page-1/#comment-1049">Meet the new : Mobilizer | Multi Purpose Responsive for Mobile &#038; Tablet</a></li><li class="recentcomments"><span class="comment-author-link">ana</span> on <a href="../../../meet-the-new-mobilizer-multi-purpose-responsive-for-mobile-tablet/comment-page-1/#comment-1044">Meet the new : Mobilizer | Multi Purpose Responsive for Mobile &#038; Tablet</a></li><li class="recentcomments"><span class="comment-author-link"><a href='../../../../pomocdrogowa24.soup.io/post/682609550/Bezpieczna-podr-w-zimie' rel='external nofollow' class='url'>Samochód zastepczy z OC sprawcy</a></span> on <a href="../../../creativity-do-creative-be-creative/comment-page-1/#comment-505">Creativity &#8211; Do and be Creative</a></li><li class="recentcomments"><span class="comment-author-link"><a href='../../../../www.arizonabankruptcylawyer.org/default.htm' rel='external nofollow' class='url'>bankruptcy</a></span> on <a href="../../../agile-and-agile-manifesto/comment-page-1/#comment-504">Agile Manifesto: What it’s about?</a></li></ul></aside></section>		<section class="wrapper-site">

		
		
		<header class="header-site header-sticky header-left" >
						<div class="container clearfix">
				<div class="logo">
	
	<a href="../../../default.htm" class="site-logo-link" rel="home"><img width="76" height="75" src="../../../wp-content/uploads/2016/07/pictweet.png" class="site-logo attachment-medium" alt="pictweet" data-size="medium" /></a>
			<div class="site-description">
						<h3 class="sitename sitetitle"><a href="../../../default.htm">Maxartkiller</a></h3>
			<p class="tagline"></p>
					</div>
	
	</div>

<nav class="nav nav-horizontal">
	
	<ul id="menu-main-menu-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-149"><a href="../../../default.htm">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-544"><a href="#">Templates</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-608"><a href="../../../freebiees/default.htm">Freebiees</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-641"><a href="#">Mobile Template</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-592"><a href="../../../max-solaris-touch-optimized-responsive-tablet-and-mobile-html-template/default.htm">Solaris | Mobile</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-593"><a href="../../../maxsmart-html-touch-optimized-responsive-tablet-and-mobile-template/default.htm">MaxSmart | Mobile</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-594"><a href="../../../mobilizer-html-touch-optimized-responsive-tablet-and-mobile-template/default.htm">Mobilizer | Mobile</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-642"><a href="#">Website</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-643"><a href="../../../admin-9-bootstrap-html-template-responsive-dashboard/default.htm">Admin9 Bootstrap</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-155"><a href="../../../blog/default.htm">Blog</a></li>
</ul>
	<a href="default.htm" class="responsive-nav"  data-toggle="#off-canvas-right" data-toggle-class="open">
	<span class="l-menu"></span>
</a>
	</nav>			</div>
					</header>

		
		<section id="wrapper-content" class="wrapper-content">
<section class="post content-main clearfix container">
    <div class="row">

        
        <article class="column span-8">
            <header class="section-title large">
			<h1 class="heading">No posts found</h1>
	</header>
<div class="story">
	<p>Use the search form below to find the page you're looking for:</p>
	<form role="search" method="get" class="search-form" action="http://maxartkiller.in/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form></div>        </article>

        							<div class="column pull-right sidebar no-gutter span-4">
							<aside id="search-6" class="content well push-bottom-large widget widget_search"><form role="search" method="get" class="search-form" action="http://maxartkiller.in/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form></aside>		<aside id="recent-posts-6" class="content well push-bottom-large widget widget_recent_entries">		<h5 class="section-nav-title">Recent Posts</h5>		<ul>
					<li>
				<a href="../../../admin9-bootstrap-admin-template-html-responsive-template/default.htm">Admin9 | bootstrap admin template | HTML responsive template</a>
						</li>
					<li>
				<a href="../../../what-are-importance-of-ux-designer-in-development-lifecycle/default.htm">What are importance of UX designer in development lifecycle?</a>
						</li>
					<li>
				<a href="../../../meet-new-new-max-smart-tablet-mobile-responsive-html-template/default.htm">Meet new new: Max Smart | Tablet &#038; Mobile Responsive HTML Template</a>
						</li>
					<li>
				<a href="../../../meet-the-new-mobilizer-multi-purpose-responsive-for-mobile-tablet/default.htm">Meet the new : Mobilizer | Multi Purpose Responsive for Mobile &#038; Tablet</a>
						</li>
					<li>
				<a href="../../../what-is-imagination-and-the-power-of-imagination/default.htm">Imagination and the Power of Imagination?</a>
						</li>
				</ul>
		</aside>		<aside id="categories-4" class="content well push-bottom-large widget widget_categories"><h5 class="section-nav-title">Categories</h5>		<ul>
	<li class="cat-item cat-item-16"><a href="../../../category/creativity/default.htm" >Creativity</a>
</li>
	<li class="cat-item cat-item-20"><a href="../../../category/devlopment-process/default.htm" >Devlopment Process</a>
</li>
	<li class="cat-item cat-item-68"><a href="../../../category/technology/default.htm" >Technology</a>
</li>
	<li class="cat-item cat-item-100"><a href="../../../category/templates/default.htm" >Templates</a>
</li>
	<li class="cat-item cat-item-76"><a href="../../../category/user-experience/default.htm" >User Experience</a>
</li>
		</ul>
</aside><aside id="woocommerce_top_rated_products-3" class="content well push-bottom-large widget woocommerce widget_top_rated_products"><h5 class="section-nav-title">Top Rated Products</h5><ul class="product_list_widget">
<li>
	<a href="../../../product/max-material-design-multipurpose-html-template/default.htm" title="Max material design  | Multipurpose HTML template">
		<img width="400" height="300" src="../../../wp-content/uploads/2016/06/cover-400x300.png" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="cover" />		<span class="product-title">Max material design  | Multipurpose HTML template</span>
	</a>
					<span class="amount">Free!</span></li>

<li>
	<a href="../../../product/max-and-johns-pizza-center-layers-wordpress-theme/default.htm" title="Max and John&#039;s - Pizza Center - Layers wordpress theme">
		<img width="400" height="356" src="../../../wp-content/uploads/2015/12/cover-400x356.png" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="cover" />		<span class="product-title">Max and John's - Pizza Center - Layers wordpress theme</span>
	</a>
					<span class="amount">Free!</span></li>

<li>
	<a href="../../../product/coupons-and-discounts-website-psd-template/default.htm" title="Coupons and Discounts | Website PSD template">
		<img width="400" height="356" src="../../../wp-content/uploads/2015/12/cover2-400x356.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="cover2" />		<span class="product-title">Coupons and Discounts | Website PSD template</span>
	</a>
					<span class="amount">Free!</span></li>

<li>
	<a href="../../../product/mr-smith-restaurant-website-design-template-ui/default.htm" title="Mr Smith | Restaurant website design template UI">
		<img width="400" height="356" src="../../../wp-content/uploads/2015/11/mr_smith_cover-400x356.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="mr_smith_cover" />		<span class="product-title">Mr Smith | Restaurant website design template UI</span>
	</a>
					<span class="amount">Free!</span></li>
</ul></aside><aside id="mailmunch_widget-3" class="content well push-bottom-large widget widget_mailmunch_widget"><div class='mailmunch-wordpress-widget mailmunch-wordpress-widget-157434' style='display: none !important;'></div></aside><aside id="tag_cloud-5" class="content well push-bottom-large widget widget_tag_cloud"><h5 class="section-nav-title">Tags</h5><div class="tagcloud"><a href='../../../tag/agile/default.htm' class='tag-link-24 tag-link-position-1' title='3 topics' style='font-size: 12.941176470588pt;'>Agile</a>
<a href='../../../tag/agile-manifesto/default.htm' class='tag-link-31 tag-link-position-2' title='2 topics' style='font-size: 10.964705882353pt;'>agile manifesto</a>
<a href='../../../tag/android/default.htm' class='tag-link-101 tag-link-position-3' title='2 topics' style='font-size: 10.964705882353pt;'>android</a>
<a href='../../../tag/apache/default.htm' class='tag-link-70 tag-link-position-4' title='2 topics' style='font-size: 10.964705882353pt;'>apache</a>
<a href='../../../tag/cordova/default.htm' class='tag-link-71 tag-link-position-5' title='2 topics' style='font-size: 10.964705882353pt;'>cordova</a>
<a href='../../../tag/creative/default.htm' class='tag-link-10 tag-link-position-6' title='10 topics' style='font-size: 20.188235294118pt;'>Creative</a>
<a href='../../../tag/creativity/default.htm' class='tag-link-27 tag-link-position-7' title='10 topics' style='font-size: 20.188235294118pt;'>creativity</a>
<a href='../../../tag/cross-plateform/default.htm' class='tag-link-72 tag-link-position-8' title='3 topics' style='font-size: 12.941176470588pt;'>cross plateform</a>
<a href='../../../tag/design-ui/default.htm' class='tag-link-30 tag-link-position-9' title='12 topics' style='font-size: 21.341176470588pt;'>design UI</a>
<a href='../../../tag/develpment/default.htm' class='tag-link-29 tag-link-position-10' title='4 topics' style='font-size: 14.588235294118pt;'>Develpment</a>
<a href='../../../tag/experience-map/default.htm' class='tag-link-78 tag-link-position-11' title='1 topic' style='font-size: 8pt;'>Experience map</a>
<a href='../../../tag/framework7/default.htm' class='tag-link-103 tag-link-position-12' title='2 topics' style='font-size: 10.964705882353pt;'>framework7</a>
<a href='../../../tag/html/default.htm' class='tag-link-106 tag-link-position-13' title='2 topics' style='font-size: 10.964705882353pt;'>html</a>
<a href='../../../tag/improvement/default.htm' class='tag-link-13 tag-link-position-14' title='8 topics' style='font-size: 18.705882352941pt;'>Improvement</a>
<a href='../../../tag/interaction-design/default.htm' class='tag-link-90 tag-link-position-15' title='6 topics' style='font-size: 17.058823529412pt;'>interaction design</a>
<a href='../../../tag/ios/default.htm' class='tag-link-102 tag-link-position-16' title='2 topics' style='font-size: 10.964705882353pt;'>ios</a>
<a href='../../../tag/latest-creative/default.htm' class='tag-link-11 tag-link-position-17' title='7 topics' style='font-size: 17.882352941176pt;'>Latest Creative</a>
<a href='../../../tag/material/default.htm' class='tag-link-88 tag-link-position-18' title='2 topics' style='font-size: 10.964705882353pt;'>Material</a>
<a href='../../../tag/material-design/default.htm' class='tag-link-89 tag-link-position-19' title='5 topics' style='font-size: 15.905882352941pt;'>material design</a>
<a href='../../../tag/material-design-html-template/default.htm' class='tag-link-109 tag-link-position-20' title='2 topics' style='font-size: 10.964705882353pt;'>material design html template</a>
<a href='../../../tag/mobile-app-templates/default.htm' class='tag-link-99 tag-link-position-21' title='1 topic' style='font-size: 8pt;'>mobile app templates</a>
<a href='../../../tag/mobile-responsive/default.htm' class='tag-link-104 tag-link-position-22' title='3 topics' style='font-size: 12.941176470588pt;'>mobile responsive</a>
<a href='../../../tag/mobile-ux/default.htm' class='tag-link-75 tag-link-position-23' title='9 topics' style='font-size: 19.529411764706pt;'>Mobile UX</a>
<a href='../../../tag/persuasion-emotion-and-trust/default.htm' class='tag-link-94 tag-link-position-24' title='2 topics' style='font-size: 10.964705882353pt;'>persuasion emotion and trust</a>
<a href='../../../tag/phonegap/default.htm' class='tag-link-69 tag-link-position-25' title='3 topics' style='font-size: 12.941176470588pt;'>phonegap</a>
<a href='../../../tag/plc/default.htm' class='tag-link-23 tag-link-position-26' title='1 topic' style='font-size: 8pt;'>PLC</a>
<a href='../../../tag/power-of-imagination/default.htm' class='tag-link-96 tag-link-position-27' title='1 topic' style='font-size: 8pt;'>power of imagination</a>
<a href='../../../tag/process/default.htm' class='tag-link-25 tag-link-position-28' title='4 topics' style='font-size: 14.588235294118pt;'>process</a>
<a href='../../../tag/responsive-mobile/default.htm' class='tag-link-105 tag-link-position-29' title='2 topics' style='font-size: 10.964705882353pt;'>responsive mobile</a>
<a href='../../../tag/responsive-mobile-html/default.htm' class='tag-link-110 tag-link-position-30' title='1 topic' style='font-size: 8pt;'>responsive mobile html</a>
<a href='../../../tag/scrum/default.htm' class='tag-link-26 tag-link-position-31' title='3 topics' style='font-size: 12.941176470588pt;'>scrum</a>
<a href='../../../tag/sdlc/default.htm' class='tag-link-22 tag-link-position-32' title='3 topics' style='font-size: 12.941176470588pt;'>SDLC</a>
<a href='../../../tag/software/default.htm' class='tag-link-28 tag-link-position-33' title='3 topics' style='font-size: 12.941176470588pt;'>software</a>
<a href='../../../tag/template/default.htm' class='tag-link-107 tag-link-position-34' title='2 topics' style='font-size: 10.964705882353pt;'>template</a>
<a href='../../../tag/thought-process/default.htm' class='tag-link-12 tag-link-position-35' title='5 topics' style='font-size: 15.905882352941pt;'>Thought process</a>
<a href='../../../tag/ui/default.htm' class='tag-link-5 tag-link-position-36' title='3 topics' style='font-size: 12.941176470588pt;'>UI</a>
<a href='../../../tag/usability-testing/default.htm' class='tag-link-91 tag-link-position-37' title='1 topic' style='font-size: 8pt;'>usability testing</a>
<a href='../../../tag/user-experience/default.htm' class='tag-link-74 tag-link-position-38' title='4 topics' style='font-size: 14.588235294118pt;'>user experience</a>
<a href='../../../tag/user-interface-design/default.htm' class='tag-link-15 tag-link-position-39' title='13 topics' style='font-size: 22pt;'>user Interface Design</a>
<a href='../../../tag/ux/default.htm' class='tag-link-6 tag-link-position-40' title='11 topics' style='font-size: 20.847058823529pt;'>UX</a>
<a href='../../../tag/user-experience-research/default.htm' class='tag-link-77 tag-link-position-41' title='6 topics' style='font-size: 17.058823529412pt;'>UX research</a>
<a href='../../../tag/visual/default.htm' class='tag-link-92 tag-link-position-42' title='2 topics' style='font-size: 10.964705882353pt;'>Visual</a>
<a href='../../../tag/visual-ui-design/default.htm' class='tag-link-93 tag-link-position-43' title='7 topics' style='font-size: 17.882352941176pt;'>visual ui design</a>
<a href='../../../tag/webdesign/default.htm' class='tag-link-14 tag-link-position-44' title='13 topics' style='font-size: 22pt;'>Webdesign</a>
<a href='../../../tag/website/default.htm' class='tag-link-108 tag-link-position-45' title='2 topics' style='font-size: 10.964705882353pt;'>website</a></div>
</aside>							</div>
					    </div>
</section>

			<div id="back-to-top">
				<a href="#top">Back to top</a>
			</div> <!-- back-to-top -->



		</section>

		
		<footer id="footer" class="footer-site">
						<div class="container  clearfix">
				
				
								<div class="row copyright">
											<div class="column span-6">
							<p class="site-text">Proudly present with ❤ by Maxartkiller.in</p>
						</div>
										<div class="column span-6 clearfix t-right">
											</div>
				</div>
							</div>
			
					</footer><!-- END / FOOTER -->
		
	</section><!-- END / MAIN SITE #wrapper -->

<script type="text/javascript"> 
	if(window.top !== window.self) {
		document.getElementsByClassName('header-site')[0].style.display='none';
	}
</script>


		<script data-cfasync="false" type="text/javascript">
var addthis_config = {"data_track_clickback":true,"ui_atversion":300,"ignore_server_config":true};
var addthis_share = {};
</script><link rel='stylesheet' id='addthis_output-group-css' href='../../../wp-content/plugins/bwp-minify/min/@f=wp-content_2Fplugins_2Faddthis_2Fcss_2Foutput.css,wp-content_2Fthemes_2Flayerswp_2Fassets_2Fcss_2Finlin01981FF3F8' type='text/css' media='all' />
<style id='layers-inline-styles-inline-css' type='text/css'>
 body { font-family: Open Sans, "Helvetica Neue", Helvetica, sans-serif;}  h1,h2,h3,h4,h5,h6, .heading { font-family: Playfair Display, "Helvetica Neue", Helvetica, sans-serif;}  button, .button, input[type=submit] { font-family: Roboto, "Helvetica Neue", Helvetica, sans-serif;}  .header-site, .header-site.header-sticky { background-color: rgba(255, 255, 255, 1); }  .footer-site { background-color: #ffffff; }  .title-container { background-color: #ffffff; } input[type="button"],  input[type="submit"],  button,  .button,  .form-submit input[type="submit"],  .invert input[type="button"],  .invert input[type="submit"],  .invert button,  .invert .button,  .invert .form-submit input[type="submit"]{ background-color: #eeeeee; color: rgba(0,0,0,.85); } input[type="button"]:hover,  input[type="submit"]:hover,  button:hover,  .button:hover,  .form-submit input[type="submit"]:hover,  .invert input[type="button"]:hover,  .invert input[type="submit"]:hover,  .invert button:hover,  .invert .button:hover,  .invert .form-submit input[type="submit"]:hover{ background-color: #f3f3f3; color: rgba(0,0,0,.85); } .copy a:not(.button),  .story a:not(.button){ color: #eeeeee;border-bottom-color: #eeeeee;} .copy a:not(.button):hover,  .story a:not(.button):hover{ color: #f3f3f3;border-bottom-color: #f3f3f3;} 
</style>
<style id='layers-custom-styles-inline-css' type='text/css'>
iframe::-webkit-scrollbar {
    width: 2px;
}
 
/* Track */
iframe::-webkit-scrollbar-track {
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3); 
    -webkit-border-radius: 10px;
    border-radius: 10px;
}
 
/* Handle */
iframe::-webkit-scrollbar-thumb {
    -webkit-border-radius: 10px;
    border-radius: 10px;
    background: rgba(255,0,0,0.8); 
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.5); 
}
iframe::-webkit-scrollbar-thumb:window-inactive {
	background: rgba(255,0,0,0.4); 
}
</style>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"../../../wp-content/plugins/contact-form-7/images/ajax-loader.gif","recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"sending":"Sending ..."};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"../../../wp-admin/admin-ajax.php","wc_ajax_url":"\/website\/mobilizer\/maxgymnasia\/contact.php?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"../../../cart/default.htm","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"../../../wp-admin/admin-ajax.php","wc_ajax_url":"\/website\/mobilizer\/maxgymnasia\/contact.php?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"../../../wp-admin/admin-ajax.php","wc_ajax_url":"\/website\/mobilizer\/maxgymnasia\/contact.php?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='../../../wp-content/plugins/bwp-minify/min/@f=wp-content_2Fplugins_2Fcontact-form-7_2Fincludes_2Fjs_2Fjquery.form.min.js,wp-content_2Fplugins_2Fconta04C7D8C31B'></script>
<!--wp_footer-->



</body>
</html>